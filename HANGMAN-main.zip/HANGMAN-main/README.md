# HANGMAN
Basic word puzzle with hangman encoded using Tkinter.<br>
If you guessed the wrong word it will create hangman else game will continue..

# Requirements
python
